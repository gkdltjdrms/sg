package com.mycompany.myapp;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletResponse;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import service.PostService; // �ùٸ� ��Ű�� ��θ� ���
import model.SearchCriteria;
import model.post; // �ùٸ� ��Ű�� ��θ� ���
import oracle.jdbc.proxy.annotation.Post;


@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	@Autowired
	private PostService postService;

	private String uploadFolder;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate);
		
		return "home";
	}
	
	//�۾��� ������ �̵�
	@RequestMapping(value = "/goToWrite", method = RequestMethod.GET)
	public String goToWrite() {
		System.out.println("���⼭ �Ǵ°ǰ�? Ȩ��Ʋ�ѷ� ȣ��");
		return "write"; // "write.jsp"�� �̵�
	}
	
	
	
	@RequestMapping(value = "/listinfo", method = RequestMethod.GET)
	public String goToPost(@RequestParam("seq") int seq, Model model) {
	    // seq�� ����Ͽ� �ش� ���� �������� ���� �߰�
	    post post = postService.getPostBySeq(seq);
	    // ���� ��� ��������
        List<File> files = postService.getFilesByListSeq(seq);
        
	    model.addAttribute("post", post);
	    model.addAttribute("files", files);

	    
	    
	    return "listinfo"; // "listinfo.jsp"�� �̵�
	}
	
	
	// �ۼ�or����
	private static final String UPLOAD_FOLDER = "C:/Users/sg/eclipse-workspace/1207copyseqcheck/src/main/webapp/resources/upload";
	@RequestMapping(value = "/writeOrUpdatePost", method = RequestMethod.POST)
	public String writeOrUpdatePost(@RequestParam("memName") String memName, @RequestParam("memId") String memId,
			@RequestParam("boardSubject") String boardSubject, @RequestParam("boardContent") String boardContent,
			@RequestParam(value = "seq", required = false) Integer seq, @RequestParam("files") MultipartFile[] files,
			Model model) {
		System.out.println("writeorupdatecontroller ��");
		Integer postSeq;

		List<String> uploadedFileNames = new ArrayList<>();
		List<String> realNames = new ArrayList<>();  // �߰�

		for (MultipartFile multipartFile : files) {
		    if (!multipartFile.isEmpty()) {
		        try {
		            // ���ϸ� �ߺ��� ���ϱ� ���� UUID ���
		            String originalFilename = multipartFile.getOriginalFilename();
		            String fileName = StringUtils.cleanPath(UUID.randomUUID().toString() + "_" + originalFilename);

		            // ���� ����
		            Path uploadPath = Paths.get(UPLOAD_FOLDER);
		            if (!Files.exists(uploadPath)) {
		                Files.createDirectories(uploadPath);
		            }
		            Path filePath = uploadPath.resolve(fileName);
		            Files.copy(multipartFile.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

		            // ����� ���ϸ� �� ���� ���ϸ��� ����Ʈ�� �߰�
		            uploadedFileNames.add(fileName);
		            realNames.add(originalFilename);  // �߰�

		        } catch (IOException e) {
		            e.printStackTrace();
		            // ���� ó��: ���� ���� ���� ��
		        }
		    }
		}

		if (seq == null) {
				// seq�� null�̸� ���ο� �� �ۼ�
			postSeq = postService.writePost(memName, memId, boardSubject, boardContent);
			System.out.println(postSeq + "seqüũ");
			System.out.println(uploadedFileNames + "���� �ҷ������� üũ");

			 // ���� ���ε� ���� ȣ��
            postService.fileUpload(postSeq, uploadedFileNames, UPLOAD_FOLDER, realNames);
		} else {
				// seq�� �����ϸ� �ش� seq�� �� ������Ʈ
			postService.updatePost(seq, memName, memId, boardSubject, boardContent);
		}

			// �ۼ� �Ǵ� ������Ʈ �Ϸ� �� ����Ʈ �������� �����̷�Ʈ
		return "redirect:/goToList";
	}
		
	@RequestMapping(value = "/downloadImage", method = RequestMethod.GET)
	public void downloadImage(@RequestParam("fileName") String fileName, HttpServletResponse response) {
	    // ���� ��� ���� (UPLOAD_FOLDER�� ���� ������ ����)
	    String filePath = UPLOAD_FOLDER + File.separator + fileName;

	    // ���� �ٿ�ε�
	    try (InputStream is = new FileInputStream(filePath);
	         OutputStream os = response.getOutputStream()) {
	        response.setContentType("application/octet-stream");
	        response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");

	        byte[] buffer = new byte[1024];
	        int bytesRead;
	        while ((bytesRead = is.read(buffer)) != -1) {
	            os.write(buffer, 0, bytesRead);
	        }
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}

	
		
		// �� ����
		@RequestMapping(value = "/deletePost", method = RequestMethod.POST)
		public String deletePost(@RequestParam("seq") Long seq) {
		    // Assuming you have a service to handle post deletion
		    postService.deletePost(seq);
		    // Redirect to the post list page after deletion
		    return "redirect:/goToList";
		}

	
		
	@RequestMapping(value = "/goToSearch", method = RequestMethod.GET)
	public String goToSearch(@ModelAttribute SearchCriteria searchCriteria, Model model) {
		List<post> searchResults = postService.searchPosts(searchCriteria);
		int totalPosts = postService.getTotalPosts(searchCriteria);

		int totalPages = (int) Math.ceil((double) totalPosts / searchCriteria.getPageSize());

		model.addAttribute("listOfPosts", searchResults);
		model.addAttribute("currentPage", searchCriteria.getPage());
		model.addAttribute("totalPages", totalPages);

		return "list";
	}

	@RequestMapping(value = "/goToList", method = RequestMethod.GET)
	public String goToList(@ModelAttribute SearchCriteria searchCriteria, Model model) {
	    List<Post> postList = postService.getPostList(
	            searchCriteria.getPage(),
	            searchCriteria.getPageSize(),
	            searchCriteria.getKeyword(),
	            searchCriteria.getSearchOption(),
	            searchCriteria.getStartDate(),
	            searchCriteria.getEndDate()
	    );

	    int totalPosts = postService.getTotalPosts(
	            searchCriteria.getKeyword(),
	            searchCriteria.getSearchOption()
	    );

	    System.out.println("22");
	    model.addAttribute("currentPage", searchCriteria.getPage());
	    int totalPages = (int) Math.ceil((double) totalPosts / searchCriteria.getPageSize());

	    model.addAttribute("listOfPosts", postList);
	    model.addAttribute("totalPages", totalPages);

	    return "list";
	}

	
	//�ø�������� ����� �ڵ�
	
	@RequestMapping(value = "/searchgo", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public  Map<String, Object> searchgo(
	        @ModelAttribute SearchCriteria searchCriteria, Model model) {
	    System.out.println("�ϴ� ajax ��Ʈ�ѷ� ��");
	    
	   
	    
	    List<Post> postList = postService.getPostList(
	            searchCriteria.getPage(),
	            searchCriteria.getPageSize(),
	            searchCriteria.getKeyword(),
	            searchCriteria.getSearchOption(),
	            searchCriteria.getStartDate(),
	            searchCriteria.getEndDate()
	    );
	    int totalPosts = postService.getTotalPosts(
	            searchCriteria.getKeyword(),
	            searchCriteria.getSearchOption()
	            
	    );
	    int totalPages = (int) Math.ceil((double) totalPosts / searchCriteria.getPageSize());
	    System.out.println("������ �Է���");
	    Map<String, Object> searchgo = new HashMap<>();
	    searchgo.put("currentPage", searchCriteria.getPage()); 
	    searchgo.put("listOfPosts", postList);
	    
	    searchgo.put("totalPages", totalPages); 
	    System.out.println("������ �Է¿Ϸ�");
	    System.out.println(searchgo);
	    return searchgo;
	}


	  
	
	//���� �������� �̵�
			@RequestMapping(value = "/goDelete", method = RequestMethod.GET)
			public String goDelete(Model model) {
				System.out.println("�ϴ� delete.jsp �� �̵��ϴ� ��Ʈ�ѷ� ");
				List<post> postList = postService.getPostList();
				model.addAttribute("listOfPosts", postList);
				return "delete"; // "delete.jsp"�� �̵�
			}
			
			@RequestMapping(value = "/deleteSelectedPosts", method = RequestMethod.POST)
			public String deleteSelectedPosts(@RequestParam(value = "selectedPosts", required = false) List<Long> selectedPosts, Model model) {
			    if (selectedPosts == null || selectedPosts.isEmpty()) {
			        // ���õ� �׸��� ���� ���, �޽����� �߰�
			        model.addAttribute("message", "üũ�� �׸��� �����ϴ�. �����Ϸ��� �׸��� �����ϼ���.");
			        return "goToList";
			    }

			    // ���õ� �׸��� �ִ� ���, ���� ����
			    postService.deleteSelectedPosts(selectedPosts);

			    return "redirect:/goToList";
			}

}
