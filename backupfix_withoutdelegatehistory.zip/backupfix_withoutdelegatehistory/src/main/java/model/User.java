package model;

import java.util.Date;

public class User {
    private String id;
    private String pwd;
    private String memName;
    private String rank;
    private String delegateapproverid;
    private Date grantstarttime;
    private Date grantendtime;

    // ������, getter, setter ���� �ʿ信 ���� �߰��� �� �ֽ��ϴ�.

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getMemName() {
        return memName;
    }

    public void setMemName(String memName) {
        this.memName = memName;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

	public String getDelegateapproverid() {
		return delegateapproverid;
	}

	public void setDelegateapproverid(String delegateapproverid) {
		this.delegateapproverid = delegateapproverid;
	}

	public Date getGrantstarttime() {
		return grantstarttime;
	}

	public void setGrantstarttime(Date grantstarttime) {
		this.grantstarttime = grantstarttime;
	}

	public Date getGrantendtime() {
		return grantendtime;
	}

	public void setGrantendtime(Date grantendtime) {
		this.grantendtime = grantendtime;
	}
}
